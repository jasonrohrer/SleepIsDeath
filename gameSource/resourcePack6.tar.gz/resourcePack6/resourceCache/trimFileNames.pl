my $files = `ls`;


my @fileList = split( /\s+/, $files );

foreach my $fileName ( @fileList ) {

	my $shortName = substr( $fileName, 0, 12 );


	print "Shortening $fileName as $shortName\n";
	rename( $fileName, $shortName );
}
